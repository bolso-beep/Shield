# Escudo Antivírus (Android)

Antivírus básico com interface limpa (4 cores), acesso a todos os arquivos,
escaneamento completo e quarentena/exclusão de arquivos suspeitos.

## Gerar o APK (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta (push).
2. Abra a aba **Actions** → workflow **Build APK** → baixe o artefato **EscudoAntivirus-apk**.
3. Instale o `app-debug.apk` no celular (permita "instalar apps desconhecidos").

## Gerar localmente
Android Studio (abrir a pasta) ou: `./gradlew assembleDebug`
→ `app/build/outputs/apk/debug/app-debug.apk`

## Como funciona
- **Permissão**: `MANAGE_EXTERNAL_STORAGE` (Android 11+) / leitura+escrita (Android 8–10).
- **Detecção**: marcador EICAR, hashes SHA-256 (`app/src/main/assets/signatures.txt`),
  dupla extensão, executáveis de Windows/ocultos, e análise de APKs (SMS + sobreposição/acessibilidade).
- **Quarentena**: move o arquivo para a pasta privada do app; dá para restaurar ou excluir.
- Limitação do Android: `Android/data` de outros apps não é acessível em versões recentes.

Teste: crie um arquivo com o texto padrão EICAR e escaneie.
