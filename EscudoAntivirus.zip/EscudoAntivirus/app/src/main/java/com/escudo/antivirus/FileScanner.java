package com.escudo.antivirus;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Mecanismo de varredura básico:
 *  1. Marcador EICAR (arquivo de teste padrão de antivírus)
 *  2. Assinaturas SHA-256 (assets/signatures.txt)
 *  3. Heurísticas de nome (dupla extensão, executáveis de Windows, executáveis ocultos)
 *  4. Análise de APKs (combinações de permissões típicas de trojans bancários)
 */
public class FileScanner {

    public interface Listener {
        void onProgress(int scanned, String currentPath);
        void onThreat(Threat threat);
    }

    private static final long MAX_HASH_SIZE = 32L * 1024 * 1024;
    private static final String EICAR_MARKER = "EICAR-STANDARD-ANTIVIRUS-TEST-FILE";

    private static final Set<String> WINDOWS_EXEC = new HashSet<>(Arrays.asList(
            "exe", "scr", "bat", "cmd", "vbs", "vbe", "jse", "wsf", "pif", "com", "msi", "lnk", "hta"));

    private static final Set<String> HIDDEN_EXEC = new HashSet<>(Arrays.asList(
            "apk", "jar", "dex", "so", "sh", "exe"));

    private static final Pattern DOUBLE_EXT = Pattern.compile(
            "(?i).+\\.(jpe?g|png|gif|pdf|docx?|xlsx?|pptx?|txt|mp3|mp4|zip)\\.(exe|scr|bat|cmd|vbs|js|jar|apk|com|pif|hta)$");

    private static final Set<String> RISKY_PERMS = new HashSet<>(Arrays.asList(
            "android.permission.SEND_SMS",
            "android.permission.READ_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.READ_CALL_LOG",
            "android.permission.RECORD_AUDIO",
            "android.permission.READ_CONTACTS",
            "android.permission.SYSTEM_ALERT_WINDOW",
            "android.permission.REQUEST_INSTALL_PACKAGES",
            "android.permission.WRITE_SETTINGS"));

    private final Context context;
    private final Map<String, String> signatures = new HashMap<>();
    private volatile boolean cancelled;

    public FileScanner(Context context) {
        this.context = context.getApplicationContext();
        loadSignatures();
    }

    public void cancel() {
        cancelled = true;
    }

    private void loadSignatures() {
        try (InputStream in = context.getAssets().open("signatures.txt");
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                int sp = line.indexOf(' ');
                String hash = (sp < 0 ? line : line.substring(0, sp)).toLowerCase(Locale.ROOT);
                String name = sp < 0 ? "Malware" : line.substring(sp + 1).trim();
                if (hash.length() == 64) signatures.put(hash, name);
            }
        } catch (IOException ignored) {
        }
    }

    /** Percorre a pasta raiz e devolve a quantidade de arquivos verificados. */
    public int scan(File root, Listener listener) {
        cancelled = false;
        int count = 0;
        long lastUpdate = 0;
        ArrayDeque<File> stack = new ArrayDeque<>();
        stack.push(root);

        while (!stack.isEmpty() && !cancelled) {
            File dir = stack.pop();
            File[] children = dir.listFiles();
            if (children == null) continue;

            for (File f : children) {
                if (cancelled) break;
                try {
                    if (Files.isSymbolicLink(f.toPath())) continue;
                } catch (Exception e) {
                    continue;
                }
                if (f.isDirectory()) {
                    stack.push(f);
                    continue;
                }
                if (!f.isFile()) continue;

                count++;
                long now = System.currentTimeMillis();
                if (now - lastUpdate > 120) {
                    lastUpdate = now;
                    listener.onProgress(count, f.getAbsolutePath());
                }

                Threat t = inspect(f);
                if (t != null) listener.onThreat(t);
            }
        }
        listener.onProgress(count, "");
        return count;
    }

    private Threat inspect(File f) {
        String path = f.getAbsolutePath();
        String name = f.getName();
        String lower = name.toLowerCase(Locale.ROOT);
        String ext = extension(lower);
        long size = f.length();

        try {
            if (size > 0 && size < 1024 && readSmall(f).contains(EICAR_MARKER)) {
                return new Threat(path, "Arquivo de teste EICAR detectado", Threat.HIGH, size);
            }
            if (size > 0 && size <= MAX_HASH_SIZE && !signatures.isEmpty()) {
                String sig = signatures.get(sha256(f));
                if (sig != null) {
                    return new Threat(path, "Assinatura conhecida: " + sig, Threat.HIGH, size);
                }
            }
        } catch (IOException ignored) {
        }

        if (DOUBLE_EXT.matcher(name).matches()) {
            return new Threat(path, "Dupla extensão enganosa (disfarçado de documento ou mídia)",
                    Threat.HIGH, size);
        }

        if (name.startsWith(".") && HIDDEN_EXEC.contains(ext)) {
            return new Threat(path, "Executável oculto no armazenamento", Threat.MEDIUM, size);
        }

        if ("apk".equals(ext)) {
            Threat t = inspectApk(f, size);
            if (t != null) return t;
        }

        if (WINDOWS_EXEC.contains(ext)) {
            return new Threat(path, "Executável de Windows no aparelho (possível disseminador de malware)",
                    Threat.MEDIUM, size);
        }
        return null;
    }

    @SuppressWarnings("deprecation")
    private Threat inspectApk(File f, long size) {
        try {
            PackageInfo info = context.getPackageManager().getPackageArchiveInfo(
                    f.getAbsolutePath(),
                    PackageManager.GET_PERMISSIONS | PackageManager.GET_SERVICES);
            if (info == null) return null;

            Set<String> perms = new HashSet<>();
            if (info.requestedPermissions != null) {
                perms.addAll(Arrays.asList(info.requestedPermissions));
            }

            boolean accessibility = false;
            if (info.services != null) {
                for (ServiceInfo s : info.services) {
                    if ("android.permission.BIND_ACCESSIBILITY_SERVICE".equals(s.permission)) {
                        accessibility = true;
                        break;
                    }
                }
            }

            boolean sms = perms.contains("android.permission.READ_SMS")
                    || perms.contains("android.permission.RECEIVE_SMS");
            boolean overlay = perms.contains("android.permission.SYSTEM_ALERT_WINDOW");

            if ((sms && (overlay || accessibility)) || (overlay && accessibility)) {
                return new Threat(f.getAbsolutePath(),
                        "APK com combinação típica de trojan bancário (SMS/sobreposição/acessibilidade)",
                        Threat.HIGH, size);
            }

            int risky = 0;
            for (String p : perms) if (RISKY_PERMS.contains(p)) risky++;
            if (risky >= 6) {
                return new Threat(f.getAbsolutePath(),
                        "APK solicita " + risky + " permissões sensíveis",
                        Threat.MEDIUM, size);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String extension(String lowerName) {
        int dot = lowerName.lastIndexOf('.');
        return dot < 0 ? "" : lowerName.substring(dot + 1);
    }

    private static String readSmall(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[1024];
            int n = in.read(buf);
            return n <= 0 ? "" : new String(buf, 0, n, StandardCharsets.ISO_8859_1);
        }
    }

    private static String sha256(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder(64);
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
