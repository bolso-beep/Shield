package com.escudo.antivirus;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private View permCard;
    private TextView title;
    private Button btnQuarantine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        permCard = findViewById(R.id.perm_card);
        title = findViewById(R.id.title);
        btnQuarantine = findViewById(R.id.btn_quarantine);

        findViewById(R.id.btn_grant).setOnClickListener(v -> requestAccess());

        findViewById(R.id.btn_scan).setOnClickListener(v -> {
            if (hasAccess()) {
                startActivity(new Intent(this, ScanActivity.class));
            } else {
                requestAccess();
            }
        });

        btnQuarantine.setOnClickListener(v ->
                startActivity(new Intent(this, QuarantineActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean ok = hasAccess();
        permCard.setVisibility(ok ? View.GONE : View.VISIBLE);
        title.setText(ok ? R.string.status_ready : R.string.status_need_permission);
        btnQuarantine.setText(getString(R.string.btn_quarantine, new Quarantine(this).list().size()));
    }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }
}
