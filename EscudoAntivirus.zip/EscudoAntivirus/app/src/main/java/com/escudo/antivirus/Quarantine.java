package com.escudo.antivirus;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Quarentena: move o arquivo para a pasta privada do app (inacessível a outros apps),
 * renomeado como ".quar", e guarda um índice com o caminho original.
 */
public class Quarantine {

    public static class Item {
        public final String id;
        public final String originalPath;
        public final String reason;
        public final long date;
        public final File file;

        Item(String id, String originalPath, String reason, long date, File file) {
            this.id = id;
            this.originalPath = originalPath;
            this.reason = reason;
            this.date = date;
            this.file = file;
        }

        public String name() {
            return new File(originalPath).getName();
        }
    }

    private static final Object LOCK = new Object();

    private final File dir;
    private final File index;

    public Quarantine(Context context) {
        dir = new File(context.getFilesDir(), "quarantine");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        index = new File(dir, "index.tsv");
    }

    public boolean add(File src, String reason) {
        synchronized (LOCK) {
            String id = UUID.randomUUID().toString();
            File dest = new File(dir, id + ".quar");
            try {
                if (!src.renameTo(dest)) {
                    copy(src, dest);
                    if (!src.delete()) {
                        //noinspection ResultOfMethodCallIgnored
                        dest.delete();
                        return false;
                    }
                }
                List<Item> items = readIndex();
                items.add(new Item(id, src.getAbsolutePath(), reason, System.currentTimeMillis(), dest));
                writeIndex(items);
                return true;
            } catch (IOException e) {
                //noinspection ResultOfMethodCallIgnored
                dest.delete();
                return false;
            }
        }
    }

    public List<Item> list() {
        synchronized (LOCK) {
            return readIndex();
        }
    }

    public boolean restore(Item item) {
        synchronized (LOCK) {
            try {
                File target = new File(item.originalPath);
                File parent = target.getParentFile();
                if (parent != null) {
                    //noinspection ResultOfMethodCallIgnored
                    parent.mkdirs();
                }
                if (target.exists()) {
                    target = new File(item.originalPath + ".restaurado");
                }
                if (!item.file.renameTo(target)) {
                    copy(item.file, target);
                    //noinspection ResultOfMethodCallIgnored
                    item.file.delete();
                }
                removeFromIndex(item.id);
                return true;
            } catch (IOException e) {
                return false;
            }
        }
    }

    public boolean deletePermanently(Item item) {
        synchronized (LOCK) {
            if (item.file.exists() && !item.file.delete()) return false;
            try {
                removeFromIndex(item.id);
            } catch (IOException e) {
                return false;
            }
            return true;
        }
    }

    // ---- índice ----

    private void removeFromIndex(String id) throws IOException {
        List<Item> items = readIndex();
        List<Item> kept = new ArrayList<>();
        for (Item i : items) if (!i.id.equals(id)) kept.add(i);
        writeIndex(kept);
    }

    private List<Item> readIndex() {
        List<Item> out = new ArrayList<>();
        if (!index.exists()) return out;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(index), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t", 4);
                if (p.length < 4) continue;
                File f = new File(dir, p[0] + ".quar");
                if (!f.exists()) continue;
                long date;
                try {
                    date = Long.parseLong(p[3]);
                } catch (NumberFormatException e) {
                    date = 0;
                }
                out.add(new Item(p[0], p[1], p[2], date, f));
            }
        } catch (IOException ignored) {
        }
        return out;
    }

    private void writeIndex(List<Item> items) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (Item i : items) {
            sb.append(i.id).append('\t')
                    .append(clean(i.originalPath)).append('\t')
                    .append(clean(i.reason)).append('\t')
                    .append(i.date).append('\n');
        }
        try (OutputStream out = new FileOutputStream(index)) {
            out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    private static String clean(String s) {
        return s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    private static void copy(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }
}
