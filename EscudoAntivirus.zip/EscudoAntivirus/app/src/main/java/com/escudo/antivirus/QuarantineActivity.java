package com.escudo.antivirus;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class QuarantineActivity extends Activity {

    private Quarantine quarantine;
    private final List<Quarantine.Item> items = new ArrayList<>();
    private QAdapter adapter;
    private View empty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quarantine);

        quarantine = new Quarantine(this);
        empty = findViewById(R.id.empty);
        adapter = new QAdapter();
        ((ListView) findViewById(R.id.list)).setAdapter(adapter);
        reload();
    }

    private void reload() {
        items.clear();
        items.addAll(quarantine.list());
        adapter.notifyDataSetChanged();
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private class QAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Quarantine.Item getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView != null ? convertView
                    : LayoutInflater.from(QuarantineActivity.this).inflate(R.layout.item_quarantine, parent, false);
            Quarantine.Item it = getItem(position);

            String date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    .format(new Date(it.date));
            ((TextView) v.findViewById(R.id.name)).setText(it.name() + "  ·  " + date);
            ((TextView) v.findViewById(R.id.reason)).setText(it.reason);
            ((TextView) v.findViewById(R.id.origin)).setText(
                    getString(R.string.quarantine_from, it.originalPath));

            v.findViewById(R.id.btn_r).setOnClickListener(b -> {
                if (quarantine.restore(it)) {
                    Toast.makeText(QuarantineActivity.this, R.string.done_restored, Toast.LENGTH_SHORT).show();
                    reload();
                } else {
                    Toast.makeText(QuarantineActivity.this, R.string.failed, Toast.LENGTH_SHORT).show();
                }
            });

            v.findViewById(R.id.btn_d).setOnClickListener(b ->
                    new AlertDialog.Builder(QuarantineActivity.this,
                            android.R.style.Theme_Material_Dialog_Alert)
                            .setTitle(R.string.confirm_delete_title)
                            .setMessage(R.string.confirm_delete_one)
                            .setPositiveButton(R.string.confirm_yes, (d, w) -> {
                                if (quarantine.deletePermanently(it)) {
                                    Toast.makeText(QuarantineActivity.this,
                                            getString(R.string.done_deleted, 1), Toast.LENGTH_SHORT).show();
                                    reload();
                                } else {
                                    Toast.makeText(QuarantineActivity.this,
                                            R.string.failed, Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton(R.string.confirm_no, null)
                            .show());
            return v;
        }
    }
}
