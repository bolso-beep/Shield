package com.escudo.antivirus;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ScanActivity extends Activity {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Threat> threats = new ArrayList<>();

    private FileScanner scanner;
    private Quarantine quarantine;
    private ThreatAdapter adapter;
    private Thread worker;
    private boolean running;

    private TextView status;
    private TextView counter;
    private TextView current;
    private ProgressBar progress;
    private Button action;
    private View bulkBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        status = findViewById(R.id.status);
        counter = findViewById(R.id.counter);
        current = findViewById(R.id.current);
        progress = findViewById(R.id.progress);
        action = findViewById(R.id.btn_action);
        bulkBar = findViewById(R.id.bulk_bar);

        scanner = new FileScanner(this);
        quarantine = new Quarantine(this);

        adapter = new ThreatAdapter();
        ((ListView) findViewById(R.id.list)).setAdapter(adapter);

        action.setOnClickListener(v -> {
            if (running) {
                scanner.cancel();
            } else {
                startScan();
            }
        });

        findViewById(R.id.btn_quarantine_all).setOnClickListener(v -> {
            int ok = 0;
            for (Threat t : new ArrayList<>(threats)) {
                if (quarantine.add(new File(t.path), t.reason)) {
                    threats.remove(t);
                    ok++;
                }
            }
            afterAction(R.string.done_quarantined, ok);
        });

        findViewById(R.id.btn_delete_all).setOnClickListener(v ->
                confirmDelete(getString(R.string.confirm_delete_many, threats.size()), () -> {
                    int ok = 0;
                    for (Threat t : new ArrayList<>(threats)) {
                        if (new File(t.path).delete()) {
                            threats.remove(t);
                            ok++;
                        }
                    }
                    afterAction(R.string.done_deleted, ok);
                }));

        startScan();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        scanner.cancel();
    }

    private void startScan() {
        threats.clear();
        adapter.notifyDataSetChanged();
        updateBulk();

        running = true;
        status.setText(R.string.scan_running);
        counter.setText("");
        current.setText("");
        progress.setVisibility(View.VISIBLE);
        action.setText(R.string.btn_stop);

        worker = new Thread(() -> {
            int total = scanner.scan(Environment.getExternalStorageDirectory(), new FileScanner.Listener() {
                @Override
                public void onProgress(int scanned, String path) {
                    ui.post(() -> {
                        counter.setText(getString(R.string.scanned_files, scanned));
                        current.setText(path);
                    });
                }

                @Override
                public void onThreat(Threat t) {
                    ui.post(() -> {
                        threats.add(t);
                        adapter.notifyDataSetChanged();
                        updateBulk();
                    });
                }
            });
            ui.post(() -> finishScan(total));
        });
        worker.start();
    }

    private void finishScan(int total) {
        running = false;
        progress.setVisibility(View.INVISIBLE);
        current.setText("");
        counter.setText(getString(R.string.scanned_files, total));
        action.setText(R.string.btn_rescan);
        refreshStatus();
    }

    private void refreshStatus() {
        if (running) return;
        if (threats.isEmpty()) {
            status.setText(R.string.scan_done_clean);
        } else {
            status.setText(getString(R.string.scan_done_threats, threats.size()));
        }
    }

    private void updateBulk() {
        bulkBar.setVisibility(threats.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void afterAction(int msg, int count) {
        adapter.notifyDataSetChanged();
        updateBulk();
        refreshStatus();
        Toast.makeText(this, getString(msg, count), Toast.LENGTH_SHORT).show();
    }

    private void confirmDelete(String message, Runnable onYes) {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(R.string.confirm_delete_title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm_yes, (d, w) -> onYes.run())
                .setNegativeButton(R.string.confirm_no, null)
                .show();
    }

    private class ThreatAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return threats.size();
        }

        @Override
        public Threat getItem(int position) {
            return threats.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView != null ? convertView
                    : LayoutInflater.from(ScanActivity.this).inflate(R.layout.item_threat, parent, false);
            Threat t = getItem(position);

            TextView sev = v.findViewById(R.id.severity);
            sev.setText(t.severity == Threat.HIGH ? R.string.severity_high : R.string.severity_medium);
            sev.setTextColor(getResources().getColor(
                    t.severity == Threat.HIGH ? R.color.danger : R.color.ink_muted, getTheme()));

            ((TextView) v.findViewById(R.id.name)).setText(
                    t.name() + "  ·  " + Formatter.formatShortFileSize(ScanActivity.this, t.size));
            ((TextView) v.findViewById(R.id.path)).setText(t.path);
            ((TextView) v.findViewById(R.id.reason)).setText(t.reason);

            v.findViewById(R.id.btn_q).setOnClickListener(b -> {
                if (quarantine.add(new File(t.path), t.reason)) {
                    threats.remove(t);
                    afterAction(R.string.done_quarantined, 1);
                } else {
                    Toast.makeText(ScanActivity.this, R.string.failed, Toast.LENGTH_SHORT).show();
                }
            });

            v.findViewById(R.id.btn_d).setOnClickListener(b ->
                    confirmDelete(getString(R.string.confirm_delete_one), () -> {
                        if (new File(t.path).delete()) {
                            threats.remove(t);
                            afterAction(R.string.done_deleted, 1);
                        } else {
                            Toast.makeText(ScanActivity.this, R.string.failed, Toast.LENGTH_SHORT).show();
                        }
                    }));
            return v;
        }
    }
}
