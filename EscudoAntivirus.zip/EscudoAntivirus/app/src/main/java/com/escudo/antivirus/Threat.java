package com.escudo.antivirus;

import java.io.File;

/** Um arquivo detectado como ameaça ou suspeito. */
public class Threat {
    public static final int MEDIUM = 1;
    public static final int HIGH = 2;

    public final String path;
    public final String reason;
    public final int severity;
    public final long size;

    public Threat(String path, String reason, int severity, long size) {
        this.path = path;
        this.reason = reason;
        this.severity = severity;
        this.size = size;
    }

    public String name() {
        return new File(path).getName();
    }
}
